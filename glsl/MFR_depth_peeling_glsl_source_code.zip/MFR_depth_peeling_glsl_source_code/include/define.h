#version 450 core
#extension GL_NV_gpu_shader5 : enable

#define sorted_by_id		0		// sort captured fragments by primitive id 
#define draw_buffers_blend	1		// blending function per MRT

#define AB_SIZE				30		// A-buffer size
#define MRT_SIZE			8		// Max MRT (KB initial implementation)

#define depth_max			1.0f
#define float_max			3.40282e+038f
#define float_min		   -3.40282e+038f
#define uint_max			4294967295